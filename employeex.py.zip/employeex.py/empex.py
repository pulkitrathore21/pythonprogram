from flask import Flask
from models import Emp,EmpStatus
from logi import getEmp,getdept
import json
app=Flask(__name__)

@app.route("/getEmployeeDetails/<x>",methods=["POST","GET"])
def getemp(x):
    result=getEmp(x)
    if result==None:
        return EmpStatus(0,"Not found",None)
    else:
        status_code=EmpStatus(1,"found",result)
        e=Emp(result.empno,result.empname,result.depid,result.mobileno)
        dict1=json.dumps(e.__dict__)
        return dict1
@app.route("/getEmployeeDeptid/<x>",methods=["POST","GET"])
def getsame(x):
    result=getdept(x)
    return json.dumps(result)
app.run(debug=True)