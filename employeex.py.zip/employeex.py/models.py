
class Emp:
    def __init__(self,empno,empname,depid,mobileno):
        self.empno=empno
        self.empname=empname
        self.depid=depid
        self.mobileno=mobileno
        

    def __str__(self):
        return f"{self.empno},{self.empname},{self.depid},{self.mobileno}"
    
class EmpStatus():
    def __init__(self,statuscode,message,employeobj):
        self.statuscode=statuscode
        self.message=message
        self.employeobj=employeobj
    def __str__(self):
        return f"{self.statuscode},{self.message},{self.employeobj}"