from sqlalchemy import create_engine,ForeignKey,Column,String,Integer,CHAR
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.dialects import  sqlite

Base =declarative_base()

class Task(Base):
    __tablename__= "task" # table name
    taskid=Column("ssn",Integer,primary_key=True)
    taskname=Column("firstname",String)
    priority=Column("lastname",String)

    def __init__(self,taskid,taskname,priority): 
        self.taskid=taskid
        self.taskname=taskname
        self.priority=priority
    
    def __repr__(self):
        return f"{self.taskid} --{self.taskname} --{self.priority}"





def poc():
 
    engine =create_engine("sqlite:///freak.db",echo=True)#rituals
    Base.metadata.create_all(bind=engine)#create tables
    Session=sessionmaker(bind=engine)#create the class
    session=Session()#object creation
    x=session.query(Task).get(1)
    session.add(x,"testing",4)
    print(x)
    

    session.commit()
    
    #results =session.query(Person).all()
    
    #results =session.query(Person).filter(Person.age < 60)
    #for r in results:
       # print(r)


   
    # t1=Thing(1,"pencil",2)
    # t2=Thing(2,"eraser",2)    
    # session.add(t1)
    # session.add(t2)
    # session.commit() 


    # results = session.query(Thing,Person).filter(Thing.owner ==Person.ssn)
    # for r in results:
    #     print(r)





    

poc()



