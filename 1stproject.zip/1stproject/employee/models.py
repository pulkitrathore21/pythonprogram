
class Emp:
    def __init__(self,empno,empname,depid,mobileno):
        self.empno=empno
        self.empname=empname
        self.depid=depid
        self.mobileno=mobileno
        

    def __str__(self):
        return f"{self.empno},{self.empname},{self.depid},{self.mobileno}"
