from flask import Flask
from flask_restful import Api,Resource
from logic import getEmp,AddEmp
import json
app=Flask(__name__)
api=Api(app)


class EmpF(Resource):
    def get(self,empno):
        result=getEmp(empno)
        x=json.dumps(result.__dict__)
        return x
    
    def post(self,empno,empname,deptid,mobileno):
        result=AddEmp(empno,empname,deptid,mobileno)
        return x
    
    def put(self,empno):
        x=json.dumps({"message":"update employee successfully"})
        return x
    
    def delete(self,empno):
        x=json.dumps({"message":"deleted  employee successfully"})
        return x
        
        

api.add_resource(EmpF,"/empobj/<int:empno>")
app.run(debug=True)


    